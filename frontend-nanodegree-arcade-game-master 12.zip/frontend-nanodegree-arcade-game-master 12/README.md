# This is an Arcade Game Project:)!

The game is about a Player trying to get to the water without colliding with the moving Bugs..

# Charecters:
1- Player 
2- Bugs

# Game Instructions 

The player needs to arrive the water area without colliding with any moving bug.
if player colides with moving bugs 3 times player loss.
if player arrived water area player wins.

# Coding parts

I used the starter code from udacity and through Visual Studio I did all my coding..
I worked on Javascript, HTML, and CSS languges.

# Resources 

As resources for this project I watched Udacity's lessons and videos.
